<?php
  //Connect to database Sever and Database
  $mysqli = new mysqli('localhost', 'root', '', 'etutoringdb');
?>